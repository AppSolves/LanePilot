# LanePilot > VEHICLE_DETECTION_V2
https://universe.roboflow.com/appsolves/lanepilot

Provided by a Roboflow user
License: CC BY 4.0

